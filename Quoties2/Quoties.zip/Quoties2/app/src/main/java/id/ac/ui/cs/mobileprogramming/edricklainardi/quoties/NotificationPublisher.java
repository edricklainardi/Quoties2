package id.ac.ui.cs.mobileprogramming.edricklainardi.quoties;

public class NotificationPublisher {
}
